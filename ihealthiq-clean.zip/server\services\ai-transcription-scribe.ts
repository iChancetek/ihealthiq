// Stub implementation for Firebase migration
// Original functionality requires refactoring to use Firestore

export class AITranscriptionScribe {
  async startTranscriptionSession(
    userId: number,
    patientId?: number,
    sessionTitle?: string
  ): Promise<{ sessionId: string; status: string }> {
    return { sessionId: 'stub_session', status: 'stub' };
  }

  async processAudioTranscription(
    sessionId: string,
    audioFileUrl: string
  ): Promise<any> {
    return {
      transcription: "Stub transcription",
      soapNotes: "{}",
      aiSummary: "Stub summary"
    };
  }

  async processRealTimeTranscription(
    sessionId: string,
    audioChunk: Buffer
  ): Promise<any> {
    return { partialTranscript: "Stub processing...", isComplete: false };
  }

  async getSessionStatus(sessionId: string): Promise<any> {
    return null;
  }

  async endTranscriptionSession(sessionId: string): Promise<void> { }
}

export const aiTranscriptionScribe = new AITranscriptionScribe();