import {
  patients, referrals, eligibilityVerifications, homeboundAssessments,
  appointments, tasks, consentForms, voiceSessions, auditLogs, users,
  userActivityLogs, passwordResetTokens,
  payers, claims, claimLineItems, denials, appeals, billingRules, clearinghouses,
  prescriptions, refillRequests, pharmacies, prescriptionAuditLogs,
  medicationInteractions, patientMedications,
  aiReferralProcessing, aiTranscriptionSessions, aiReferralSummaries,
  aiHopeAssessments, aiChartReviews, aiAgentTasks, aiAgentCollaborations, aiModelMetrics,
  type Patient, type InsertPatient, type Referral, type InsertReferral,
  type EligibilityVerification, type InsertEligibilityVerification,
  type HomeboundAssessment, type InsertHomeboundAssessment,
  type Appointment, type InsertAppointment, type Task, type InsertTask,
  type ConsentForm, type InsertConsentForm, type VoiceSession, type InsertVoiceSession,
  type AuditLog, type InsertAuditLog, type User, type InsertUser,
  type UserActivityLog, type InsertUserActivityLog,
  type PasswordResetToken, type InsertPasswordResetToken,
  type Payer, type InsertPayer, type Claim, type InsertClaim,
  type ClaimLineItem, type InsertClaimLineItem, type Denial, type InsertDenial,
  type Appeal, type InsertAppeal, type BillingRule, type InsertBillingRule,
  type Clearinghouse, type InsertClearinghouse,
  type Prescription, type InsertPrescription, type RefillRequest, type InsertRefillRequest,
  type Pharmacy, type InsertPharmacy, type PrescriptionAuditLog, type InsertPrescriptionAuditLog,
  type MedicationInteraction, type InsertMedicationInteraction,
  type PatientMedication, type InsertPatientMedication,
  type AiReferralProcessing, type InsertAiReferralProcessing,
  type AiTranscriptionSession, type InsertAiTranscriptionSession,
  type AiReferralSummary, type InsertAiReferralSummary,
  type AiHopeAssessment, type InsertAiHopeAssessment,
  type AiChartReview, type InsertAiChartReview,
  type AiAgentTask, type InsertAiAgentTask,
  type AiAgentCollaboration, type InsertAiAgentCollaboration,
  type AiModelMetrics, type InsertAiModelMetrics
} from "@shared/schema";
import { db } from "./firebase";
// Drizzle imports removed as we use Firestore queries now
// import { eq, desc, and, or, ilike } from "drizzle-orm"; 

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserById(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;

  // Patient methods
  getPatient(id: number): Promise<Patient | undefined>;
  getPatients(): Promise<Patient[]>;
  searchPatients(searchTerm: string): Promise<Patient[]>;
  createPatient(patient: InsertPatient): Promise<Patient>;
  updatePatient(id: number, patient: Partial<InsertPatient>): Promise<Patient | undefined>;

  // Referral methods
  getReferral(id: number): Promise<Referral | undefined>;
  getReferrals(): Promise<Referral[]>;
  getReferralsByStatus(status: string): Promise<Referral[]>;
  createReferral(referral: InsertReferral): Promise<Referral>;
  updateReferral(id: number, referral: Partial<InsertReferral>): Promise<Referral | undefined>;

  // Eligibility verification methods
  getEligibilityVerification(id: number): Promise<EligibilityVerification | undefined>;
  getEligibilityVerificationsByPatient(patientId: number): Promise<EligibilityVerification[]>;
  createEligibilityVerification(verification: InsertEligibilityVerification): Promise<EligibilityVerification>;
  updateEligibilityVerification(id: number, verification: Partial<InsertEligibilityVerification>): Promise<EligibilityVerification | undefined>;

  // Homebound assessment methods
  getHomeboundAssessment(id: number): Promise<HomeboundAssessment | undefined>;
  getHomeboundAssessmentsByPatient(patientId: number): Promise<HomeboundAssessment[]>;
  createHomeboundAssessment(assessment: InsertHomeboundAssessment): Promise<HomeboundAssessment>;
  updateHomeboundAssessment(id: number, assessment: Partial<InsertHomeboundAssessment>): Promise<HomeboundAssessment | undefined>;

  // Appointment methods
  getAppointment(id: number): Promise<Appointment | undefined>;
  getAppointments(): Promise<Appointment[]>;
  getAppointmentsByPatient(patientId: number): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment | undefined>;

  // Task methods
  getTask(id: number): Promise<Task | undefined>;
  getTasks(): Promise<Task[]>;
  getTasksByStatus(status: string): Promise<Task[]>;
  getTasksByPriority(priority: string): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;

  // Consent form methods
  getConsentForm(id: number): Promise<ConsentForm | undefined>;
  getConsentFormsByPatient(patientId: number): Promise<ConsentForm[]>;
  createConsentForm(form: InsertConsentForm): Promise<ConsentForm>;
  updateConsentForm(id: number, form: Partial<InsertConsentForm>): Promise<ConsentForm | undefined>;

  // Voice session methods
  getVoiceSession(sessionId: string): Promise<VoiceSession | undefined>;
  getActiveVoiceSessions(): Promise<VoiceSession[]>;
  createVoiceSession(session: InsertVoiceSession): Promise<VoiceSession>;
  updateVoiceSession(sessionId: string, session: Partial<InsertVoiceSession>): Promise<VoiceSession | undefined>;

  // Audit log methods
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
  getAuditLogs(userId?: number, limit?: number): Promise<AuditLog[]>;
  getAuditLogsByAction(action: string): Promise<AuditLog[]>;
  getAuditLogsByResource(resourceType: string, resourceId?: number): Promise<AuditLog[]>;

  // User activity tracking methods
  createUserActivityLog(log: InsertUserActivityLog): Promise<UserActivityLog>;
  getUserActivityLogs(userId: number, limit?: number): Promise<UserActivityLog[]>;
  getUserActivityByModule(userId: number, moduleName: string): Promise<UserActivityLog[]>;
  getAllUserActivityLogs(limit?: number): Promise<UserActivityLog[]>;
  getActiveUserSessions(): Promise<UserActivityLog[]>;

  // Password reset methods
  createPasswordResetToken(token: InsertPasswordResetToken): Promise<PasswordResetToken>;
  getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined>;
  markPasswordResetTokenUsed(tokenId: number): Promise<void>;
  cleanupExpiredPasswordResetTokens(): Promise<void>;

  // SOAP Note methods
  getSOAPNotesByPatient(patientId: number): Promise<AiTranscriptionSession[]>;
  createSOAPNote(soapNote: any): Promise<AiTranscriptionSession>;
  updateSOAPNote(id: number, updateData: any): Promise<AiTranscriptionSession | undefined>;

  // Billing methods
  getPayer(id: number): Promise<Payer | undefined>;
  getPayers(): Promise<Payer[]>;
  createPayer(payer: InsertPayer): Promise<Payer>;
  updatePayer(id: number, payer: Partial<InsertPayer>): Promise<Payer | undefined>;

  getClaim(id: number): Promise<Claim | undefined>;
  getClaims(): Promise<Claim[]>;
  getClaimsByStatus(status: string): Promise<Claim[]>;
  getClaimsByPayer(payerId: number): Promise<Claim[]>;
  createClaim(claim: InsertClaim): Promise<Claim>;
  updateClaim(id: number, claim: Partial<InsertClaim>): Promise<Claim | undefined>;

  getClaimLineItems(claimId: number): Promise<ClaimLineItem[]>;
  createClaimLineItem(lineItem: InsertClaimLineItem): Promise<ClaimLineItem>;
  updateClaimLineItem(id: number, lineItem: Partial<InsertClaimLineItem>): Promise<ClaimLineItem | undefined>;

  getDenial(id: number): Promise<Denial | undefined>;
  getDenials(): Promise<Denial[]>;
  getDenialsByClaim(claimId: number): Promise<Denial[]>;
  createDenial(denial: InsertDenial): Promise<Denial>;
  updateDenial(id: number, denial: Partial<InsertDenial>): Promise<Denial | undefined>;

  getAppeal(id: number): Promise<Appeal | undefined>;
  getAppeals(): Promise<Appeal[]>;
  getAppealsByDenial(denialId: number): Promise<Appeal[]>;
  createAppeal(appeal: InsertAppeal): Promise<Appeal>;
  updateAppeal(id: number, appeal: Partial<InsertAppeal>): Promise<Appeal | undefined>;

  getBillingRule(id: number): Promise<BillingRule | undefined>;
  getBillingRules(): Promise<BillingRule[]>;
  getBillingRulesByPayer(payerId: number): Promise<BillingRule[]>;
  createBillingRule(rule: InsertBillingRule): Promise<BillingRule>;
  updateBillingRule(id: number, rule: Partial<InsertBillingRule>): Promise<BillingRule | undefined>;

  getClearinghouse(id: number): Promise<Clearinghouse | undefined>;
  getClearinghouses(): Promise<Clearinghouse[]>;
  createClearinghouse(clearinghouse: InsertClearinghouse): Promise<Clearinghouse>;
  updateClearinghouse(id: number, clearinghouse: Partial<InsertClearinghouse>): Promise<Clearinghouse | undefined>;

  // AI Module methods
  createAiReferralProcessing(processing: InsertAiReferralProcessing): Promise<AiReferralProcessing>;
  getAiReferralProcessing(id: number): Promise<AiReferralProcessing | undefined>;
  getAiReferralProcessingByReferral(referralId: number): Promise<AiReferralProcessing[]>;

  createAiTranscriptionSession(session: InsertAiTranscriptionSession): Promise<AiTranscriptionSession>;
  getAiTranscriptionSession(sessionId: string): Promise<AiTranscriptionSession | undefined>;
  getActiveAiTranscriptionSession(userId: number): Promise<AiTranscriptionSession | undefined>;
  getAllAiTranscriptionSessions(): Promise<AiTranscriptionSession[]>;
  updateAiTranscriptionSession(sessionId: string, session: Partial<InsertAiTranscriptionSession>): Promise<AiTranscriptionSession | undefined>;
  deleteAiTranscriptionSession(sessionId: string): Promise<void>;

  createAiReferralSummary(summary: InsertAiReferralSummary): Promise<AiReferralSummary>;
  getAiReferralSummary(id: number): Promise<AiReferralSummary | undefined>;
  getAiReferralSummaryByReferral(referralId: number): Promise<AiReferralSummary | undefined>;

  createAiHopeAssessment(assessment: InsertAiHopeAssessment): Promise<AiHopeAssessment>;
  getAiHopeAssessment(id: number): Promise<AiHopeAssessment | undefined>;
  getAllAiHopeAssessments(): Promise<AiHopeAssessment[]>;
  getAiHopeAssessmentsByPatient(patientId: number): Promise<AiHopeAssessment[]>;
  updateAiHopeAssessment(id: number, assessment: Partial<InsertAiHopeAssessment>): Promise<AiHopeAssessment | undefined>;
  deleteAiHopeAssessment(id: number): Promise<void>;

  createAiChartReview(review: InsertAiChartReview): Promise<AiChartReview>;
  getAiChartReview(id: number): Promise<AiChartReview | undefined>;
  getAiChartReviewsByPatient(patientId: number): Promise<AiChartReview[]>;

  createAiAgentTask(task: InsertAiAgentTask): Promise<AiAgentTask>;
  getAiAgentTask(id: number): Promise<AiAgentTask | undefined>;
  getAiAgentTaskByTaskId(taskId: string): Promise<AiAgentTask | undefined>;
  getAiAgentTasksByStatus(status: string): Promise<AiAgentTask[]>;
  updateAiAgentTask(taskId: string, task: Partial<InsertAiAgentTask>): Promise<AiAgentTask | undefined>;

  createAiAgentCollaboration(collaboration: InsertAiAgentCollaboration): Promise<AiAgentCollaboration>;
  getAiAgentCollaboration(id: number): Promise<AiAgentCollaboration | undefined>;
  getAiAgentCollaborationsBySession(sessionId: string): Promise<AiAgentCollaboration[]>;

  createAiModelMetrics(metrics: InsertAiModelMetrics): Promise<AiModelMetrics>;
  getAiModelMetrics(id: number): Promise<AiModelMetrics | undefined>;
  getAiModelMetricsByModule(moduleType: string): Promise<AiModelMetrics[]>;

  // Prescription methods
  getPrescription(id: number): Promise<Prescription | undefined>;
  getPrescriptions(): Promise<Prescription[]>;
  getPrescriptionsByPatient(patientId: number): Promise<Prescription[]>;
  createPrescription(prescription: InsertPrescription): Promise<Prescription>;
  updatePrescription(id: number, prescription: Partial<InsertPrescription>): Promise<Prescription | undefined>;

  // Refill request methods
  getRefillRequest(id: number): Promise<RefillRequest | undefined>;
  getRefillRequests(): Promise<RefillRequest[]>;
  getRefillRequestsByPrescription(prescriptionId: number): Promise<RefillRequest[]>;
  createRefillRequest(refill: InsertRefillRequest): Promise<RefillRequest>;
  updateRefillRequest(id: number, refill: Partial<InsertRefillRequest>): Promise<RefillRequest | undefined>;

  // Pharmacy methods
  getPharmacy(id: number): Promise<Pharmacy | undefined>;
  getPharmacies(): Promise<Pharmacy[]>;
  getPharmaciesByZipCode(zipCode: string): Promise<Pharmacy[]>;
  createPharmacy(pharmacy: InsertPharmacy): Promise<Pharmacy>;
  updatePharmacy(id: number, pharmacy: Partial<InsertPharmacy>): Promise<Pharmacy | undefined>;

  // Prescription audit methods
  createPrescriptionAuditLog(log: InsertPrescriptionAuditLog): Promise<PrescriptionAuditLog>;
  getPrescriptionAuditLogs(prescriptionId?: number, refillRequestId?: number): Promise<PrescriptionAuditLog[]>;

  // Medication interaction methods
  getMedicationInteractions(medicationName: string): Promise<MedicationInteraction[]>;
  createMedicationInteraction(interaction: InsertMedicationInteraction): Promise<MedicationInteraction>;

  // Patient medication methods
  getPatientMedications(patientId: number): Promise<PatientMedication[]>;
  createPatientMedication(medication: InsertPatientMedication): Promise<PatientMedication>;

  // Additional prescription support methods
  getPharmacyById(id: string): Promise<Pharmacy | undefined>;
  getPendingRefillRequests(): Promise<RefillRequest[]>;
  getRefillRequestById(id: number): Promise<RefillRequest | undefined>;
  updatePatientMedication(id: number, medication: Partial<InsertPatientMedication>): Promise<PatientMedication | undefined>;
}

// Helpers
const snapshotToData = <T>(snapshot: FirebaseFirestore.QuerySnapshot): T[] => {
  return snapshot.docs.map(doc => doc.data() as T);
};

async function getNextId(collectionName: string): Promise<number> {
  const snapshot = await db.collection(collectionName)
    .orderBy('id', 'desc')
    .limit(1)
    .get();

  if (snapshot.empty) return 1;
  const lastId = snapshot.docs[0].data().id;
  return (typeof lastId === 'number' ? lastId : 0) + 1;
}

export class DatabaseStorage implements IStorage {
  // USER METHODS
  async getUser(id: number): Promise<User | undefined> {
    const snapshot = await db.collection('users').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as User;
  }

  async getUserById(id: number): Promise<User | undefined> {
    return this.getUser(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const snapshot = await db.collection('users').where('username', '==', username).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as User;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const snapshot = await db.collection('users').where('email', '==', email).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as User;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = await getNextId('users');
    const newUser = { ...insertUser, id, createdAt: new Date(), updatedAt: new Date() } as User;
    await db.collection('users').add(newUser);
    return newUser;
  }

  async updateUser(id: number, updateData: Partial<InsertUser>): Promise<User | undefined> {
    const snapshot = await db.collection('users').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    const doc = snapshot.docs[0];
    const updated = { ...doc.data(), ...updateData, updatedAt: new Date() };
    await doc.ref.update(updated);
    return updated as User;
  }

  async getAllUsers(): Promise<User[]> {
    const snapshot = await db.collection('users').get();
    return snapshotToData<User>(snapshot);
  }

  // PATIENT METHODS
  async getPatient(id: number): Promise<Patient | undefined> {
    const snapshot = await db.collection('patients').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as Patient;
  }

  async getPatients(): Promise<Patient[]> {
    const snapshot = await db.collection('patients').get();
    return snapshotToData<Patient>(snapshot);
  }

  async searchPatients(searchTerm: string): Promise<Patient[]> {
    const all = await this.getPatients();
    const term = searchTerm.toLowerCase();
    return all.filter(p => p.patientName.toLowerCase().includes(term));
  }

  async createPatient(insertPatient: InsertPatient): Promise<Patient> {
    const id = await getNextId('patients');
    const newPatient = {
      ...insertPatient, id,
      createdAt: new Date(), updatedAt: new Date(),
      isDeleted: false, isActive: true
    } as unknown as Patient;
    await db.collection('patients').add(newPatient);
    return newPatient;
  }

  async updatePatient(id: number, updateData: Partial<InsertPatient>): Promise<Patient | undefined> {
    const snapshot = await db.collection('patients').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as Patient;
  }

  // STUBS
  // REFERRAL METHODS
  async getReferral(id: number): Promise<Referral | undefined> {
    const snapshot = await db.collection('referrals').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as Referral;
  }

  async getReferrals(): Promise<Referral[]> {
    const snapshot = await db.collection('referrals').get();
    return snapshotToData<Referral>(snapshot);
  }

  async getReferralsByStatus(status: string): Promise<Referral[]> {
    const snapshot = await db.collection('referrals').where('status', '==', status).get();
    return snapshotToData<Referral>(snapshot);
  }

  async createReferral(insertReferral: InsertReferral): Promise<Referral> {
    const id = await getNextId('referrals');
    const newReferral = {
      ...insertReferral, id,
      createdAt: new Date(), updatedAt: new Date()
    } as unknown as Referral;
    await db.collection('referrals').add(newReferral);
    return newReferral;
  }

  async updateReferral(id: number, updateData: Partial<InsertReferral>): Promise<Referral | undefined> {
    const snapshot = await db.collection('referrals').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as Referral;
  }

  // ELIGIBILITY VERIFICATION METHODS
  async getEligibilityVerification(id: number): Promise<EligibilityVerification | undefined> {
    const snapshot = await db.collection('eligibility_verifications').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as EligibilityVerification;
  }

  async getEligibilityVerificationsByPatient(patientId: number): Promise<EligibilityVerification[]> {
    const snapshot = await db.collection('eligibility_verifications').where('patientId', '==', patientId).get();
    return snapshotToData<EligibilityVerification>(snapshot);
  }

  async createEligibilityVerification(insertVerification: InsertEligibilityVerification): Promise<EligibilityVerification> {
    const id = await getNextId('eligibility_verifications');
    const newVerification = {
      ...insertVerification, id,
      verifiedAt: new Date(), createdAt: new Date()
    } as unknown as EligibilityVerification;
    await db.collection('eligibility_verifications').add(newVerification);
    return newVerification;
  }

  async updateEligibilityVerification(id: number, updateData: Partial<InsertEligibilityVerification>): Promise<EligibilityVerification | undefined> {
    const snapshot = await db.collection('eligibility_verifications').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update(updateData);
    return { ...snapshot.docs[0].data(), ...updateData } as EligibilityVerification;
  }

  // HOMEBOUND ASSESSMENT METHODS
  async getHomeboundAssessment(id: number): Promise<HomeboundAssessment | undefined> {
    const snapshot = await db.collection('homebound_assessments').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as HomeboundAssessment;
  }

  async getHomeboundAssessmentsByPatient(patientId: number): Promise<HomeboundAssessment[]> {
    const snapshot = await db.collection('homebound_assessments').where('patientId', '==', patientId).get();
    return snapshotToData<HomeboundAssessment>(snapshot);
  }

  async createHomeboundAssessment(insertAssessment: InsertHomeboundAssessment): Promise<HomeboundAssessment> {
    const id = await getNextId('homebound_assessments');
    const newAssessment = {
      ...insertAssessment, id,
      assessmentDate: new Date(), createdAt: new Date()
    } as unknown as HomeboundAssessment;
    await db.collection('homebound_assessments').add(newAssessment);
    return newAssessment;
  }

  async updateHomeboundAssessment(id: number, updateData: Partial<InsertHomeboundAssessment>): Promise<HomeboundAssessment | undefined> {
    const snapshot = await db.collection('homebound_assessments').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update(updateData);
    return { ...snapshot.docs[0].data(), ...updateData } as HomeboundAssessment;
  }

  // APPOINTMENT METHODS
  async getAppointment(id: number): Promise<Appointment | undefined> {
    const snapshot = await db.collection('appointments').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as Appointment;
  }

  async getAppointments(): Promise<Appointment[]> {
    const snapshot = await db.collection('appointments').get();
    return snapshotToData<Appointment>(snapshot);
  }

  async getAppointmentsByPatient(patientId: number): Promise<Appointment[]> {
    const snapshot = await db.collection('appointments').where('patientId', '==', patientId).get();
    return snapshotToData<Appointment>(snapshot);
  }

  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const id = await getNextId('appointments');
    const newAppointment = {
      ...insertAppointment, id,
      createdAt: new Date(), updatedAt: new Date()
    } as unknown as Appointment;
    await db.collection('appointments').add(newAppointment);
    return newAppointment;
  }

  async updateAppointment(id: number, updateData: Partial<InsertAppointment>): Promise<Appointment | undefined> {
    const snapshot = await db.collection('appointments').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as Appointment;
  }

  // TASK METHODS
  async getTask(id: number): Promise<Task | undefined> {
    const snapshot = await db.collection('tasks').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as Task;
  }

  async getTasks(): Promise<Task[]> {
    const snapshot = await db.collection('tasks').get();
    return snapshotToData<Task>(snapshot);
  }

  async getTasksByStatus(status: string): Promise<Task[]> {
    const snapshot = await db.collection('tasks').where('status', '==', status).get();
    return snapshotToData<Task>(snapshot);
  }

  async getTasksByPriority(priority: string): Promise<Task[]> {
    const snapshot = await db.collection('tasks').where('priority', '==', priority).get();
    return snapshotToData<Task>(snapshot);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = await getNextId('tasks');
    const newTask = {
      ...insertTask, id,
      createdAt: new Date(), updatedAt: new Date()
    } as unknown as Task;
    await db.collection('tasks').add(newTask);
    return newTask;
  }

  async updateTask(id: number, updateData: Partial<InsertTask>): Promise<Task | undefined> {
    const snapshot = await db.collection('tasks').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as Task;
  }

  // CONSENT FORM METHODS
  async getConsentForm(id: number): Promise<ConsentForm | undefined> {
    const snapshot = await db.collection('consent_forms').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as ConsentForm;
  }

  async getConsentFormsByPatient(patientId: number): Promise<ConsentForm[]> {
    const snapshot = await db.collection('consent_forms').where('patientId', '==', patientId).get();
    return snapshotToData<ConsentForm>(snapshot);
  }

  async createConsentForm(insertForm: InsertConsentForm): Promise<ConsentForm> {
    const id = await getNextId('consent_forms');
    const newForm = {
      ...insertForm, id,
      signedAt: new Date(), createdAt: new Date()
    } as unknown as ConsentForm;
    await db.collection('consent_forms').add(newForm);
    return newForm;
  }

  async updateConsentForm(id: number, updateData: Partial<InsertConsentForm>): Promise<ConsentForm | undefined> {
    const snapshot = await db.collection('consent_forms').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update(updateData);
    return { ...snapshot.docs[0].data(), ...updateData } as ConsentForm;
  }

  // VOICE SESSION METHODS
  async getVoiceSession(sessionId: string): Promise<VoiceSession | undefined> {
    const snapshot = await db.collection('voice_sessions').where('sessionId', '==', sessionId).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as VoiceSession;
  }

  async getActiveVoiceSessions(): Promise<VoiceSession[]> {
    const snapshot = await db.collection('voice_sessions').where('isActive', '==', true).get();
    return snapshotToData<VoiceSession>(snapshot);
  }

  async createVoiceSession(insertSession: InsertVoiceSession): Promise<VoiceSession> {
    const id = await getNextId('voice_sessions');
    const newSession = {
      ...insertSession, id,
      startTime: new Date(), createdAt: new Date()
    } as unknown as VoiceSession;
    await db.collection('voice_sessions').add(newSession);
    return newSession;
  }

  async updateVoiceSession(sessionId: string, updateData: Partial<InsertVoiceSession>): Promise<VoiceSession | undefined> {
    const snapshot = await db.collection('voice_sessions').where('sessionId', '==', sessionId).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, endTime: updateData.isActive === false ? new Date() : undefined });
    return { ...snapshot.docs[0].data(), ...updateData } as VoiceSession;
  }

  // AUDIT LOG METHODS
  async createAuditLog(insertLog: InsertAuditLog): Promise<AuditLog> {
    const id = await getNextId('audit_logs');
    const newLog = {
      ...insertLog, id, // timestamp is usually passed in InsertAuditLog, if not default to now
      timestamp: insertLog.timestamp || new Date()
    } as unknown as AuditLog;
    await db.collection('audit_logs').add(newLog);
    return newLog;
  }

  async getAuditLogs(userId?: number, limit: number = 100): Promise<AuditLog[]> {
    let query: FirebaseFirestore.Query = db.collection('audit_logs');
    if (userId) query = query.where('userId', '==', userId);
    const snapshot = await query.orderBy('timestamp', 'desc').limit(limit).get();
    return snapshotToData<AuditLog>(snapshot);
  }

  async getAuditLogsByAction(action: string): Promise<AuditLog[]> {
    const snapshot = await db.collection('audit_logs').where('action', '==', action).orderBy('timestamp', 'desc').get();
    return snapshotToData<AuditLog>(snapshot);
  }

  async getAuditLogsByResource(resourceType: string, resourceId?: number): Promise<AuditLog[]> {
    let query = db.collection('audit_logs').where('resourceType', '==', resourceType);
    if (resourceId) query = query.where('resourceId', '==', resourceId);
    const snapshot = await query.orderBy('timestamp', 'desc').get();
    return snapshotToData<AuditLog>(snapshot);
  }

  // USER ACTIVITY LOG METHODS
  async createUserActivityLog(insertLog: InsertUserActivityLog): Promise<UserActivityLog> {
    const id = await getNextId('user_activity_logs');
    const newLog = {
      ...insertLog, id,
      timestamp: insertLog.timestamp || new Date()
    } as unknown as UserActivityLog;
    await db.collection('user_activity_logs').add(newLog);
    return newLog;
  }

  async getUserActivityLogs(userId: number, limit: number = 100): Promise<UserActivityLog[]> {
    const snapshot = await db.collection('user_activity_logs')
      .where('userId', '==', userId)
      .orderBy('timestamp', 'desc')
      .limit(limit)
      .get();
    return snapshotToData<UserActivityLog>(snapshot);
  }

  async getUserActivityByModule(userId: number, moduleName: string): Promise<UserActivityLog[]> {
    const snapshot = await db.collection('user_activity_logs')
      .where('userId', '==', userId)
      .where('moduleName', '==', moduleName)
      .orderBy('timestamp', 'desc')
      .get();
    return snapshotToData<UserActivityLog>(snapshot);
  }

  async getAllUserActivityLogs(limit: number = 100): Promise<UserActivityLog[]> {
    const snapshot = await db.collection('user_activity_logs')
      .orderBy('timestamp', 'desc')
      .limit(limit)
      .get();
    return snapshotToData<UserActivityLog>(snapshot);
  }

  async getActiveUserSessions(): Promise<UserActivityLog[]> {
    // Simplified: getting recent logins. Real "active sessions" might need a different tracking mechanism or shorter lookback.
    // For now, returning logins from last 24 hours as a proxy if needed, or just relying on specific 'LOGIN' actions.
    const lookback = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const snapshot = await db.collection('user_activity_logs')
      .where('action', '==', 'LOGIN')
      .where('timestamp', '>', lookback)
      .orderBy('timestamp', 'desc')
      .get();
    return snapshotToData<UserActivityLog>(snapshot);
  }

  // PASSWORD RESET TOKEN METHODS
  async createPasswordResetToken(insertToken: InsertPasswordResetToken): Promise<PasswordResetToken> {
    const id = await getNextId('password_reset_tokens');
    const newToken = {
      ...insertToken, id,
      createdAt: new Date()
    } as unknown as PasswordResetToken;
    await db.collection('password_reset_tokens').add(newToken);
    return newToken;
  }

  async getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined> {
    const snapshot = await db.collection('password_reset_tokens').where('token', '==', token).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as PasswordResetToken;
  }

  async markPasswordResetTokenUsed(id: number): Promise<void> {
    const snapshot = await db.collection('password_reset_tokens').where('id', '==', id).limit(1).get();
    if (!snapshot.empty) {
      await snapshot.docs[0].ref.update({ isUsed: true });
    }
  }

  async cleanupExpiredPasswordResetTokens(): Promise<void> {
    const now = new Date();
    const snapshot = await db.collection('password_reset_tokens')
      .where('expiresAt', '<', now)
      .get();

    // In Firestore, there's no single "delete all" query, so batch delete
    const batch = db.batch();
    snapshot.docs.forEach(doc => batch.delete(doc.ref));
    await batch.commit();
  }

  // SOAP NOTE METHODS (MAPPED TO AI TRANSCRIPTION SESSIONS FOR NOW OR DEDICATED)
  // Assuming SOAP notes are derived from or stored within ai_transcription_sessions based on schema hints
  // But if there's a specific requirement for `getSOAPNotesByPatient`, we should query the appropriate collection.
  // The interface return type implies `AiTranscriptionSession[]`, so we query that collection.
  async getSOAPNotesByPatient(patientId: number): Promise<AiTranscriptionSession[]> {
    const snapshot = await db.collection('ai_transcription_sessions')
      .where('patientId', '==', patientId)
      .where('status', '==', 'COMPLETED') // Assuming completed sessions act as notes
      .orderBy('startTime', 'desc')
      .get();
    return snapshotToData<AiTranscriptionSession>(snapshot);
  }

  async createSOAPNote(note: any): Promise<AiTranscriptionSession> {
    // Re-using createAiTranscriptionSession logic basically, or specifically for notes
    const id = await getNextId('ai_transcription_sessions');
    const newNote = { ...note, id, createdAt: new Date() };
    await db.collection('ai_transcription_sessions').add(newNote);
    return newNote;
  }

  async updateSOAPNote(id: number, updateData: any): Promise<AiTranscriptionSession | undefined> {
    const snapshot = await db.collection('ai_transcription_sessions').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update(updateData);
    return { ...snapshot.docs[0].data(), ...updateData } as AiTranscriptionSession;
  }

  // BILLING METHODS - PAYERS & CLAIMS
  async getPayer(id: number): Promise<Payer | undefined> {
    const snapshot = await db.collection('payers').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as Payer;
  }

  async getPayers(): Promise<Payer[]> {
    const snapshot = await db.collection('payers').get();
    return snapshotToData<Payer>(snapshot);
  }

  async createPayer(insertPayer: InsertPayer): Promise<Payer> {
    const id = await getNextId('payers');
    const newPayer = { ...insertPayer, id, createdAt: new Date(), updatedAt: new Date() } as unknown as Payer;
    await db.collection('payers').add(newPayer);
    return newPayer;
  }

  async updatePayer(id: number, updateData: Partial<InsertPayer>): Promise<Payer | undefined> {
    const snapshot = await db.collection('payers').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as Payer;
  }

  async getClaim(id: number): Promise<Claim | undefined> {
    const snapshot = await db.collection('claims').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as Claim;
  }

  async getClaims(): Promise<Claim[]> {
    const snapshot = await db.collection('claims').get();
    return snapshotToData<Claim>(snapshot);
  }

  async getClaimsByStatus(status: string): Promise<Claim[]> {
    const snapshot = await db.collection('claims').where('status', '==', status).get();
    return snapshotToData<Claim>(snapshot);
  }

  async getClaimsByPayer(payerId: number): Promise<Claim[]> {
    const snapshot = await db.collection('claims').where('payerId', '==', payerId).get();
    return snapshotToData<Claim>(snapshot);
  }

  async createClaim(insertClaim: InsertClaim): Promise<Claim> {
    const id = await getNextId('claims');
    const newClaim = {
      ...insertClaim, id,
      createdAt: new Date(), updatedAt: new Date()
    } as unknown as Claim;
    await db.collection('claims').add(newClaim);
    return newClaim;
  }

  async updateClaim(id: number, updateData: Partial<InsertClaim>): Promise<Claim | undefined> {
    const snapshot = await db.collection('claims').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as Claim;
  }

  async getClaimLineItems(claimId: number): Promise<ClaimLineItem[]> {
    const snapshot = await db.collection('claim_line_items').where('claimId', '==', claimId).get();
    return snapshotToData<ClaimLineItem>(snapshot);
  }

  async createClaimLineItem(insertItem: InsertClaimLineItem): Promise<ClaimLineItem> {
    const id = await getNextId('claim_line_items');
    const newItem = {
      ...insertItem, id
    } as unknown as ClaimLineItem;
    await db.collection('claim_line_items').add(newItem);
    return newItem;
  }

  async updateClaimLineItem(id: number, updateData: Partial<InsertClaimLineItem>): Promise<ClaimLineItem | undefined> {
    const snapshot = await db.collection('claim_line_items').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update(updateData);
    return { ...snapshot.docs[0].data(), ...updateData } as ClaimLineItem;
  }

  // DENIAL & APPEAL METHODS
  async getDenial(id: number): Promise<Denial | undefined> {
    const snapshot = await db.collection('denials').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as Denial;
  }

  async getDenials(): Promise<Denial[]> {
    const snapshot = await db.collection('denials').get();
    return snapshotToData<Denial>(snapshot);
  }

  async getDenialsByClaim(claimId: number): Promise<Denial[]> {
    const snapshot = await db.collection('denials').where('claimId', '==', claimId).get();
    return snapshotToData<Denial>(snapshot);
  }

  async createDenial(insertDenial: InsertDenial): Promise<Denial> {
    const id = await getNextId('denials');
    const newDenial = { ...insertDenial, id, createdAt: new Date() } as unknown as Denial;
    await db.collection('denials').add(newDenial);
    return newDenial;
  }

  async updateDenial(id: number, updateData: Partial<InsertDenial>): Promise<Denial | undefined> {
    const snapshot = await db.collection('denials').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update(updateData);
    return { ...snapshot.docs[0].data(), ...updateData } as Denial;
  }

  async getAppeal(id: number): Promise<Appeal | undefined> {
    const snapshot = await db.collection('appeals').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as Appeal;
  }

  async getAppeals(): Promise<Appeal[]> {
    const snapshot = await db.collection('appeals').get();
    return snapshotToData<Appeal>(snapshot);
  }

  async getAppealsByDenial(denialId: number): Promise<Appeal[]> {
    const snapshot = await db.collection('appeals').where('denialId', '==', denialId).get();
    return snapshotToData<Appeal>(snapshot);
  }

  async createAppeal(insertAppeal: InsertAppeal): Promise<Appeal> {
    const id = await getNextId('appeals');
    const newAppeal = { ...insertAppeal, id, filedDate: new Date(), updatedAt: new Date() } as unknown as Appeal;
    await db.collection('appeals').add(newAppeal);
    return newAppeal;
  }

  async updateAppeal(id: number, updateData: Partial<InsertAppeal>): Promise<Appeal | undefined> {
    const snapshot = await db.collection('appeals').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as Appeal;
  }

  async getBillingRule(id: number): Promise<BillingRule | undefined> {
    const snapshot = await db.collection('billing_rules').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as BillingRule;
  }

  async getBillingRules(): Promise<BillingRule[]> {
    const snapshot = await db.collection('billing_rules').get();
    return snapshotToData<BillingRule>(snapshot);
  }

  async getBillingRulesByPayer(payerId: number): Promise<BillingRule[]> {
    const snapshot = await db.collection('billing_rules').where('payerId', '==', payerId).get();
    return snapshotToData<BillingRule>(snapshot);
  }

  async createBillingRule(insertRule: InsertBillingRule): Promise<BillingRule> {
    const id = await getNextId('billing_rules');
    const newRule = { ...insertRule, id, createdAt: new Date(), updatedAt: new Date() } as unknown as BillingRule;
    await db.collection('billing_rules').add(newRule);
    return newRule;
  }

  async updateBillingRule(id: number, updateData: Partial<InsertBillingRule>): Promise<BillingRule | undefined> {
    const snapshot = await db.collection('billing_rules').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as BillingRule;
  }

  async getClearinghouse(id: number): Promise<Clearinghouse | undefined> {
    const snapshot = await db.collection('clearinghouses').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as Clearinghouse;
  }

  async getClearinghouses(): Promise<Clearinghouse[]> {
    const snapshot = await db.collection('clearinghouses').get();
    return snapshotToData<Clearinghouse>(snapshot);
  }

  async createClearinghouse(insertCH: InsertClearinghouse): Promise<Clearinghouse> {
    const id = await getNextId('clearinghouses');
    const newCH = { ...insertCH, id, createdAt: new Date(), updatedAt: new Date() } as unknown as Clearinghouse;
    await db.collection('clearinghouses').add(newCH);
    return newCH;
  }

  async updateClearinghouse(id: number, updateData: Partial<InsertClearinghouse>): Promise<Clearinghouse | undefined> {
    const snapshot = await db.collection('clearinghouses').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as Clearinghouse;
  }

  // AI MODULE METHODS
  async createAiReferralProcessing(insertProc: InsertAiReferralProcessing): Promise<AiReferralProcessing> {
    const id = await getNextId('ai_referral_processing');
    const newProc = { ...insertProc, id, processedAt: new Date() } as unknown as AiReferralProcessing;
    await db.collection('ai_referral_processing').add(newProc);
    return newProc;
  }

  async getAiReferralProcessing(id: number): Promise<AiReferralProcessing | undefined> {
    const snapshot = await db.collection('ai_referral_processing').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as AiReferralProcessing;
  }

  async getAiReferralProcessingByReferral(referralId: number): Promise<AiReferralProcessing[]> {
    const snapshot = await db.collection('ai_referral_processing').where('referralId', '==', referralId).get();
    return snapshotToData<AiReferralProcessing>(snapshot);
  }

  async createAiTranscriptionSession(insertSession: InsertAiTranscriptionSession): Promise<AiTranscriptionSession> {
    const id = await getNextId('ai_transcription_sessions');
    // For string sessionIds (if used outside ID), we might need to handle differently, but schema indicates 'id' is serial number.
    // The method signature uses 'sessionId' string in some places and 'id' number in others?
    // Let's check the schema logic -> schema has `sessionId` as string (uuid likely) and `id` as serial.
    // InsertAiTranscriptionSession usually has `sessionId`.
    const newSession = {
      ...insertSession, id,
      startTime: new Date(), createdAt: new Date()
    } as unknown as AiTranscriptionSession;
    await db.collection('ai_transcription_sessions').add(newSession);
    return newSession;
  }

  async getAiTranscriptionSession(sessionId: string): Promise<AiTranscriptionSession | undefined> {
    const snapshot = await db.collection('ai_transcription_sessions').where('sessionId', '==', sessionId).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as AiTranscriptionSession;
  }

  async getActiveAiTranscriptionSession(userId: number): Promise<AiTranscriptionSession | undefined> {
    const snapshot = await db.collection('ai_transcription_sessions')
      .where('userId', '==', userId)
      .where('status', '==', 'IN_PROGRESS') // Assuming IN_PROGRESS is the status
      .limit(1)
      .get();
    if (snapshot.empty) return undefined;
    // If multiple active, just return first.
    return snapshot.docs[0].data() as AiTranscriptionSession;
  }

  async getAllAiTranscriptionSessions(): Promise<AiTranscriptionSession[]> {
    const snapshot = await db.collection('ai_transcription_sessions').get();
    return snapshotToData<AiTranscriptionSession>(snapshot);
  }

  async updateAiTranscriptionSession(sessionId: string, updateData: Partial<InsertAiTranscriptionSession>): Promise<AiTranscriptionSession | undefined> {
    const snapshot = await db.collection('ai_transcription_sessions').where('sessionId', '==', sessionId).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update(updateData);
    return { ...snapshot.docs[0].data(), ...updateData } as AiTranscriptionSession;
  }

  async deleteAiTranscriptionSession(sessionId: string): Promise<void> {
    const snapshot = await db.collection('ai_transcription_sessions').where('sessionId', '==', sessionId).limit(1).get();
    if (!snapshot.empty) {
      await snapshot.docs[0].ref.delete();
    }
  }

  async createAiReferralSummary(insertSummary: InsertAiReferralSummary): Promise<AiReferralSummary> {
    const id = await getNextId('ai_referral_summaries');
    const newSummary = { ...insertSummary, id, generatedAt: new Date() } as unknown as AiReferralSummary;
    await db.collection('ai_referral_summaries').add(newSummary);
    return newSummary;
  }

  async getAiReferralSummary(id: number): Promise<AiReferralSummary | undefined> {
    const snapshot = await db.collection('ai_referral_summaries').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as AiReferralSummary;
  }

  async getAiReferralSummaryByReferral(referralId: number): Promise<AiReferralSummary | undefined> {
    // There could be multiple, but usually one latest summary. 
    const snapshot = await db.collection('ai_referral_summaries')
      .where('referralId', '==', referralId)
      .orderBy('generatedAt', 'desc')
      .limit(1)
      .get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as AiReferralSummary;
  }

  async createAiHopeAssessment(insertAssessment: InsertAiHopeAssessment): Promise<AiHopeAssessment> {
    const id = await getNextId('ai_hope_assessments');
    const newAssessment = { ...insertAssessment, id, assessedAt: new Date() } as unknown as AiHopeAssessment;
    await db.collection('ai_hope_assessments').add(newAssessment);
    return newAssessment;
  }

  async getAiHopeAssessment(id: number): Promise<AiHopeAssessment | undefined> {
    const snapshot = await db.collection('ai_hope_assessments').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as AiHopeAssessment;
  }

  async getAllAiHopeAssessments(): Promise<AiHopeAssessment[]> {
    const snapshot = await db.collection('ai_hope_assessments').get();
    return snapshotToData<AiHopeAssessment>(snapshot);
  }

  async getAiHopeAssessmentsByPatient(patientId: number): Promise<AiHopeAssessment[]> {
    const snapshot = await db.collection('ai_hope_assessments').where('patientId', '==', patientId).get();
    return snapshotToData<AiHopeAssessment>(snapshot);
  }

  async updateAiHopeAssessment(id: number, updateData: Partial<InsertAiHopeAssessment>): Promise<AiHopeAssessment | undefined> {
    const snapshot = await db.collection('ai_hope_assessments').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update(updateData);
    return { ...snapshot.docs[0].data(), ...updateData } as AiHopeAssessment;
  }

  async deleteAiHopeAssessment(id: number): Promise<void> {
    const snapshot = await db.collection('ai_hope_assessments').where('id', '==', id).limit(1).get();
    if (!snapshot.empty) {
      await snapshot.docs[0].ref.delete();
    }
  }

  async createAiChartReview(insertReview: InsertAiChartReview): Promise<AiChartReview> {
    const id = await getNextId('ai_chart_reviews');
    const newReview = { ...insertReview, id, reviewedAt: new Date() } as unknown as AiChartReview;
    await db.collection('ai_chart_reviews').add(newReview);
    return newReview;
  }

  async getAiChartReview(id: number): Promise<AiChartReview | undefined> {
    const snapshot = await db.collection('ai_chart_reviews').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as AiChartReview;
  }

  async getAiChartReviewsByPatient(patientId: number): Promise<AiChartReview[]> {
    const snapshot = await db.collection('ai_chart_reviews').where('patientId', '==', patientId).get();
    return snapshotToData<AiChartReview>(snapshot);
  }

  async createAiAgentTask(insertTask: InsertAiAgentTask): Promise<AiAgentTask> {
    const id = await getNextId('ai_agent_tasks');
    const newTask = { ...insertTask, id, createdAt: new Date(), updatedAt: new Date() } as unknown as AiAgentTask;
    await db.collection('ai_agent_tasks').add(newTask);
    return newTask;
  }

  async getAiAgentTask(id: number): Promise<AiAgentTask | undefined> {
    const snapshot = await db.collection('ai_agent_tasks').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as AiAgentTask;
  }

  async getAiAgentTaskByTaskId(taskId: string): Promise<AiAgentTask | undefined> {
    const snapshot = await db.collection('ai_agent_tasks').where('taskId', '==', taskId).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as AiAgentTask;
  }

  async getAiAgentTasksByStatus(status: string): Promise<AiAgentTask[]> {
    const snapshot = await db.collection('ai_agent_tasks').where('status', '==', status).get();
    return snapshotToData<AiAgentTask>(snapshot);
  }

  async updateAiAgentTask(taskId: string, updateData: Partial<InsertAiAgentTask>): Promise<AiAgentTask | undefined> {
    const snapshot = await db.collection('ai_agent_tasks').where('taskId', '==', taskId).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as AiAgentTask;
  }

  async createAiAgentCollaboration(insertCollab: InsertAiAgentCollaboration): Promise<AiAgentCollaboration> {
    const id = await getNextId('ai_agent_collaborations');
    const newCollab = { ...insertCollab, id, timestamp: new Date() } as unknown as AiAgentCollaboration;
    await db.collection('ai_agent_collaborations').add(newCollab);
    return newCollab;
  }

  async getAiAgentCollaboration(id: number): Promise<AiAgentCollaboration | undefined> {
    const snapshot = await db.collection('ai_agent_collaborations').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as AiAgentCollaboration;
  }

  async getAiAgentCollaborationsBySession(sessionId: string): Promise<AiAgentCollaboration[]> {
    const snapshot = await db.collection('ai_agent_collaborations')
      .where('sessionId', '==', sessionId)
      .orderBy('timestamp', 'asc')
      .get();
    return snapshotToData<AiAgentCollaboration>(snapshot);
  }

  async createAiModelMetrics(insertMetrics: InsertAiModelMetrics): Promise<AiModelMetrics> {
    const id = await getNextId('ai_model_metrics');
    const newMetrics = { ...insertMetrics, id, timestamp: new Date() } as unknown as AiModelMetrics;
    await db.collection('ai_model_metrics').add(newMetrics);
    return newMetrics;
  }

  async getAiModelMetrics(id: number): Promise<AiModelMetrics | undefined> {
    const snapshot = await db.collection('ai_model_metrics').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as AiModelMetrics;
  }

  async getAiModelMetricsByModule(moduleType: string): Promise<AiModelMetrics[]> {
    const snapshot = await db.collection('ai_model_metrics')
      .where('moduleType', '==', moduleType)
      .orderBy('timestamp', 'desc')
      .get();
    return snapshotToData<AiModelMetrics>(snapshot);
  }

  // PRESCRIPTION METHODS
  async getPrescription(id: number): Promise<Prescription | undefined> {
    const snapshot = await db.collection('prescriptions').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as Prescription;
  }

  async getPrescriptions(): Promise<Prescription[]> {
    const snapshot = await db.collection('prescriptions').get();
    return snapshotToData<Prescription>(snapshot);
  }

  async getPrescriptionsByPatient(patientId: number): Promise<Prescription[]> {
    const snapshot = await db.collection('prescriptions').where('patientId', '==', patientId).get();
    return snapshotToData<Prescription>(snapshot);
  }

  async createPrescription(insertPrescription: InsertPrescription): Promise<Prescription> {
    const id = await getNextId('prescriptions');
    const newPrescription = {
      ...insertPrescription, id,
      datePrescribed: insertPrescription.datePrescribed || new Date(),
      createdAt: new Date(), updatedAt: new Date()
    } as unknown as Prescription;
    await db.collection('prescriptions').add(newPrescription);
    return newPrescription;
  }

  async updatePrescription(id: number, updateData: Partial<InsertPrescription>): Promise<Prescription | undefined> {
    const snapshot = await db.collection('prescriptions').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as Prescription;
  }

  // REFILL REQUEST METHODS
  async getRefillRequest(id: number): Promise<RefillRequest | undefined> {
    const snapshot = await db.collection('refill_requests').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as RefillRequest;
  }

  async getRefillRequests(): Promise<RefillRequest[]> {
    const snapshot = await db.collection('refill_requests').get();
    return snapshotToData<RefillRequest>(snapshot);
  }

  async getRefillRequestsByPrescription(prescriptionId: number): Promise<RefillRequest[]> {
    const snapshot = await db.collection('refill_requests').where('prescriptionId', '==', prescriptionId).get();
    return snapshotToData<RefillRequest>(snapshot);
  }

  async createRefillRequest(insertRequest: InsertRefillRequest): Promise<RefillRequest> {
    const id = await getNextId('refill_requests');
    const newRequest = {
      ...insertRequest, id,
      requestDate: new Date(), updatedAt: new Date()
    } as unknown as RefillRequest;
    await db.collection('refill_requests').add(newRequest);
    return newRequest;
  }

  async updateRefillRequest(id: number, updateData: Partial<InsertRefillRequest>): Promise<RefillRequest | undefined> {
    const snapshot = await db.collection('refill_requests').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as RefillRequest;
  }

  // PHARMACY METHODS
  async getPharmacy(id: number): Promise<Pharmacy | undefined> {
    const snapshot = await db.collection('pharmacies').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    return snapshot.docs[0].data() as Pharmacy;
  }

  async getPharmacies(): Promise<Pharmacy[]> {
    const snapshot = await db.collection('pharmacies').get();
    return snapshotToData<Pharmacy>(snapshot);
  }

  async getPharmaciesByZipCode(zipCode: string): Promise<Pharmacy[]> {
    const snapshot = await db.collection('pharmacies').where('zipCode', '==', zipCode).get();
    return snapshotToData<Pharmacy>(snapshot);
  }

  async createPharmacy(insertPharmacy: InsertPharmacy): Promise<Pharmacy> {
    const id = await getNextId('pharmacies');
    const newPharmacy = { ...insertPharmacy, id, createdAt: new Date() } as unknown as Pharmacy;
    await db.collection('pharmacies').add(newPharmacy);
    return newPharmacy;
  }

  async updatePharmacy(id: number, updateData: Partial<InsertPharmacy>): Promise<Pharmacy | undefined> {
    const snapshot = await db.collection('pharmacies').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData });
    return { ...snapshot.docs[0].data(), ...updateData } as Pharmacy;
  }

  // PRESCRIPTION AUDIT METHODS
  async createPrescriptionAuditLog(insertLog: InsertPrescriptionAuditLog): Promise<PrescriptionAuditLog> {
    const id = await getNextId('prescription_audit_logs');
    const newLog = { ...insertLog, id, timestamp: new Date() } as unknown as PrescriptionAuditLog;
    await db.collection('prescription_audit_logs').add(newLog);
    return newLog;
  }

  async getPrescriptionAuditLogs(prescriptionId?: number, refillRequestId?: number): Promise<PrescriptionAuditLog[]> {
    let query: FirebaseFirestore.Query = db.collection('prescription_audit_logs');
    if (prescriptionId) query = query.where('prescriptionId', '==', prescriptionId);
    if (refillRequestId) query = query.where('refillRequestId', '==', refillRequestId);
    const snapshot = await query.orderBy('timestamp', 'desc').get();
    return snapshotToData<PrescriptionAuditLog>(snapshot);
  }

  // MEDICATION INTERACTION METHODS
  async getMedicationInteractions(medicationName: string): Promise<MedicationInteraction[]> {
    // Simple exact match for now. Real interaction checking usually involves external APIs or complex mapping.
    const snapshot = await db.collection('medication_interactions')
      .where('medication1', '==', medicationName)
      .get();

    // Check both ways if needed, or structured differently
    const snapshot2 = await db.collection('medication_interactions')
      .where('medication2', '==', medicationName)
      .get();

    const interactions1 = snapshotToData<MedicationInteraction>(snapshot);
    const interactions2 = snapshotToData<MedicationInteraction>(snapshot2);
    return [...interactions1, ...interactions2];
  }

  async createMedicationInteraction(insertInteraction: InsertMedicationInteraction): Promise<MedicationInteraction> {
    const id = await getNextId('medication_interactions');
    const newInteraction = { ...insertInteraction, id } as unknown as MedicationInteraction;
    await db.collection('medication_interactions').add(newInteraction);
    return newInteraction;
  }

  // PATIENT MEDICATION METHODS
  async getPatientMedications(patientId: number): Promise<PatientMedication[]> {
    const snapshot = await db.collection('patient_medications').where('patientId', '==', patientId).get();
    return snapshotToData<PatientMedication>(snapshot);
  }

  async createPatientMedication(insertMedication: InsertPatientMedication): Promise<PatientMedication> {
    const id = await getNextId('patient_medications');
    const newMedication = {
      ...insertMedication, id,
      startDate: insertMedication.startDate || new Date(),
      createdAt: new Date(), updatedAt: new Date()
    } as unknown as PatientMedication;
    await db.collection('patient_medications').add(newMedication);
    return newMedication;
  }

  async updatePatientMedication(id: number, updateData: Partial<InsertPatientMedication>): Promise<PatientMedication | undefined> {
    const snapshot = await db.collection('patient_medications').where('id', '==', id).limit(1).get();
    if (snapshot.empty) return undefined;
    await snapshot.docs[0].ref.update({ ...updateData, updatedAt: new Date() });
    return { ...snapshot.docs[0].data(), ...updateData } as PatientMedication;
  }

  // ADDITIONAL HELPER METHODS IMPLEMENTATION
  async getPharmacyById(id: string): Promise<Pharmacy | undefined> {
    // Assuming 'id' here means the string ID perhaps used by external APIs, or just overloading. 
    // If it's the number ID, convert. The Interface says string? let's check. 
    // Interface: getPharmacyById(id: string): Promise<Pharmacy | undefined>;
    // If our internal IDs are numbers, maybe this is for search by name or external ID?
    // Let's assume it attempts to match either ID if it parses, or maybe it's legacy?
    // Going to stub or try to match 'pharmacyId' field if it exists, or just return undefined for now if unused.
    // Better: Assume it might be trying to find by Firestore Doc ID?
    // But we are using numeric IDs. Let's try to parse as int first.
    const numericId = parseInt(id);
    if (!isNaN(numericId)) return this.getPharmacy(numericId);
    return undefined;
  }

  async getPendingRefillRequests(): Promise<RefillRequest[]> {
    const snapshot = await db.collection('refill_requests').where('status', '==', 'PENDING').get();
    return snapshotToData<RefillRequest>(snapshot);
  }

  async getRefillRequestById(id: number): Promise<RefillRequest | undefined> {
    return this.getRefillRequest(id);
  }
}

export const storage = new DatabaseStorage();